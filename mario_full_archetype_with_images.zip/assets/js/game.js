
var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 480,
    parent: "game",
    scene: { preload, create, update }
};

var game = new Phaser.Game(config);

function preload() {
    this.load.image("bg", "assets/images/bg.png");
}

function create() {
    this.add.image(400, 240, "bg").setScale(1);
    this.add.text(200, 200, "Mario Placeholder Game", { fontSize: "28px", fill: "#fff" });
}

function update() {}
