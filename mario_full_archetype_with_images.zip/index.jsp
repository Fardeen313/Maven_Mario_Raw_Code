
<!DOCTYPE html>
<html>
<head>
<title>Mario Game</title>
<script src="assets/js/phaser.min.js"></script>
<script src="assets/js/game.js"></script>
</head>
<body>
<h2>Mario Game Loaded</h2>
<canvas id="game"></canvas>
</body>
</html>
